Somewhat Classic Hangman-README.TXT
---------------------------------------------------------
-V 2.2 I fixed all the errors I put into V 2.1 when I was
       fixing it. It will now load without any errors, I
       removed the absolute reference to a file on my comuter
       which was the culprit, I also fixed some spelling errors
       on the names in the credits, sorry it was late and I was
       tired. I am hoping that this is actually the working
       version, sorry to all the people that had to return the
       disks to me, I hope it works for you now.
-V 2.1 I fixed the score troubles with two players, so now
       you don't have to exit completely to reset them.

-V 2.0 The first release, everything is new.
---------------------------------------------------------
This is a file where I put all the last minute info that
will help you run the hangman game.


1.) Why is it fading so slow?
if you experience this, I have on some computers, then
just open the hangman.ini file, if you are in windows,
you can just double click it. and replace the one in 
the first line with a 0 so the line looks like this:

	fades = 0

don't change the word fades at all or the case of any
letters as this will cause problems in the program and
if you want any fades at any time it will not work.


I know of no further problems due to the fact I only have
one computer, so if you run into any just email me at
	
	EVILDEATHMAN@JUNO.COM

I would really apprichiate it, just tell me what you were
trying to do when the error occured and what happened after.


I take no responsibility for anything that happens by your using
this game. but I hope you have fun.

Please feel free to distribute this game, but don't forget to
credit me for making it. Thank you.

