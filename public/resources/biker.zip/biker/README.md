# Biker

A Tron/snake style game where you and a friend can play against each other
as a line that needs to avoid running into anything. 

I added an animated explosion when a player runs into something.


